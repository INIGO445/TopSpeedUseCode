using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using System;
using Google.MiniJSON;
using System.Linq;


public class Temporizador : MonoBehaviour
{
    //Atributos para hacer funcional el cronometro
    private float timer = 0f;               
    private bool isTiming = false;          
    public Collider startFinishTrigger;     
    public Collider checkpointTrigger;      
    public Collider F1Jugador;
    private bool passedCheckpoint = false;  
    public List<float> lapTimes = new List<float>(); 
    private string nombreUsuario = GameManager.Instance.nombreJugador;
    void Start()
    {
        
    }
    //Actualiza el temporizador
    void Update()
    {
        if (isTiming)
        {
            timer += Time.deltaTime;
        }
    }
    //Metodo para poder gestionar el cronometro
    private void OnTriggerEnter(Collider other)
    {
        if (other == startFinishTrigger && F1Jugador.CompareTag("Jugador"))
        {
            if (!isTiming)
            {
                // Inicio del cronómetro
                isTiming = true;
                timer = 0f;
                passedCheckpoint = false;
                startFinishTrigger.enabled = false;
            }
            else if (passedCheckpoint)
            {
                // Vuelta completada
                lapTimes.Add(timer);
                Debug.Log($"Vuelta completada - Tiempo: {FormatTime(timer)}");
                StartCoroutine(EnviarTest());

                // Reset para la siguiente vuelta
                timer = 0f;
                passedCheckpoint = false;
                checkpointTrigger.enabled = true;
                startFinishTrigger.enabled = false;
            }
        }
        else if (other == checkpointTrigger && F1Jugador.CompareTag("Jugador"))
        {
            passedCheckpoint = true;
            checkpointTrigger.enabled = false;
            startFinishTrigger.enabled = true;
        }
    }
    //Metodo para el formato de tiempo
    public string FormatTime(float time)
    {
        int minutes = Mathf.FloorToInt(time / 60f);
        int seconds = Mathf.FloorToInt(time % 60f);
        int milliseconds = Mathf.FloorToInt((time * 1000f) % 1000f);
        return $"{minutes:00}:{seconds:00}:{milliseconds:000}";
    }
    //Metodo para que una vez cruzado por meta, se hacen varias peticiones
    IEnumerator EnviarTest()
    {
        string url = $"https://topspeed-51f83-default-rtdb.europe-west1.firebasedatabase.app/prueba/{nombreUsuario}.json";
        float tiempoNuevo = timer;
        string json = $"{{\"Nombre\": \"{nombreUsuario}\", \"Tiempo\": {tiempoNuevo.ToString(System.Globalization.CultureInfo.InvariantCulture)}}}";
        UnityWebRequest get = UnityWebRequest.Get(url);

        yield return get.SendWebRequest();

        float? tiempoGuardado = null;
        bool hayTiempo = false;

        if (get.result == UnityWebRequest.Result.Success)
        {
            string getJson = get.downloadHandler.text;

            if (!string.IsNullOrEmpty(getJson) && getJson != "null")
            {
                try
                {
                    DatosTiempo datos = JsonUtility.FromJson<DatosTiempo>(getJson);
                    tiempoGuardado = datos.Tiempo;
                    Debug.Log("Tiempo guardado: " + tiempoGuardado.Value);
                    hayTiempo = true;
                }
                catch (Exception e)
                {
                    Debug.LogError("Error al deserializar el JSON: " + e.Message);
                    hayTiempo = false;
                }
            }
            else
            {
                Debug.Log("ℹNo hay tiempo guardado aún.");
                hayTiempo = false;
            }

            if (!tiempoGuardado.HasValue || tiempoNuevo < tiempoGuardado.Value || !hayTiempo)
            {
                UnityWebRequest request = new UnityWebRequest(url, "PUT");
                byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(json);
                request.uploadHandler = new UploadHandlerRaw(bodyRaw);
                request.downloadHandler = new DownloadHandlerBuffer();
                request.SetRequestHeader("Content-Type", "application/json");

                yield return request.SendWebRequest();

                if (request.result == UnityWebRequest.Result.Success)
                {
                    Debug.Log("¡Datos enviados correctamente!");
                }
                else
                {
                    Debug.LogError("Error al enviar: " + request.error);
                }
            }
            else
            {
                Debug.Log("ℹEl tiempo actual no es mejor que el guardado. No se actualizó la base de datos.");
            }
        }
        else
        {
            Debug.LogError("Error al obtener los datos del tiempo guardado: " + get.error);
        }
    }
}

[Serializable]
public class DatosTiempo
{
    public string Nombre;
    public float Tiempo;
}
