using UnityEngine;
using System;
using System.Collections.Generic;

public class IA : MonoBehaviour
{
    //Enum para identificar si el eje es delantero o trasero
    public enum Axel
    {
        Front,
        Rear
    }
    //Struct para la Rueda
    [Serializable]
    public struct Wheel
    {
        public GameObject wheelModel;
        public WheelCollider wheelCollider;
        public Axel axel;
    }
    //Atributos para el que el coche pueda hacer movientos de izquierda a derecha acelerar y frenar/Saber donde frenar y saber por donde tiene que ir
    public float maxAcceleration = 500.0f;
    public float brakeAcceleration = 3000.0f;
    public float maxSteerAngle = 30.0f;
    public int currentWaypoint;
    public Vector3 _centerOfMass = new Vector3(0, -0.9f, 0);
    public List<Wheel> wheels;
    public WaypointContainer waypointContainer;
    public List<Transform> waypoints;
    public List<Transform> zonasFrenado;
    private Rigidbody carRb;
    private float moveInput = 1.0f;
    private bool enZonaFrenado = false;
    public float waypointrange = 10f;
    public Transform zonaFrenadoPadre;
    //Inicializacion de los atributos, modificacion del agarre del coche
    void Start()
    {
        carRb = GetComponent<Rigidbody>();
        carRb.centerOfMass = _centerOfMass;
        waypoints = waypointContainer.waypoints;
        currentWaypoint = 0;

        if (zonaFrenadoPadre != null)
        {
            zonasFrenado = new List<Transform>();
            foreach (Transform child in zonaFrenadoPadre)
            {
                zonasFrenado.Add(child);
            }
        }

        foreach (var wheel in wheels)
        {
            WheelFrictionCurve forwardFriction = wheel.wheelCollider.forwardFriction;
            WheelFrictionCurve sidewaysFriction = wheel.wheelCollider.sidewaysFriction;
            forwardFriction.stiffness = 1.5f;
            sidewaysFriction.stiffness = (wheel.axel == Axel.Rear) ? 3.5f : 2.5f;
            wheel.wheelCollider.forwardFriction = forwardFriction;
            wheel.wheelCollider.sidewaysFriction = sidewaysFriction;
        }
    }
    //Metodos de uso para que ir actualizando el giro, freno y checkpoints
    void Update()
    {
        AnimateWheels();
        CheckWaypoint();
        DebugRay();
    }

    void LateUpdate()
    {
        Move();
        Steer();
    }
    //Cambio de checkpoints
    void CheckWaypoint()
    {
        if (waypoints.Count == 0) return;

        if (Vector3.Distance(waypoints[currentWaypoint].position, transform.position) < waypointrange)
        {
            currentWaypoint++;
            if (currentWaypoint == waypoints.Count) currentWaypoint = 0;
        }
    }
    //Frenada
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Zonafrenado"))
        {
            enZonaFrenado = true;
        }
    }
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Zonafrenado"))
        {
            enZonaFrenado = false;
        }
    }
    //Metodo para que sepamos a que waypoint esta llendo el coche
    void DebugRay()
    {
        if (waypoints.Count > 0)
        {
            Debug.DrawRay(transform.position, waypoints[currentWaypoint].position - transform.position, Color.blue);
        }
    }
    //Metodo de calculo de giro que debe hacer el coche
    void Steer()
    {
        if (waypoints.Count == 0) return;

        Vector3 localTarget = transform.InverseTransformPoint(waypoints[currentWaypoint].position);
        float lateralOffset = localTarget.x;
        float steerInput = -Mathf.Clamp(lateralOffset / 5f, -1f, 1f);
        float speed = carRb.velocity.magnitude;
        float speedFactor = Mathf.Clamp01(speed / 50f);
        float adjustedSteer = Mathf.Lerp(maxSteerAngle, maxSteerAngle * 0.4f, speedFactor);

        foreach (var wheel in wheels)
        {
            if (wheel.axel == Axel.Front)
            {
                wheel.wheelCollider.steerAngle = Mathf.Lerp(
                    wheel.wheelCollider.steerAngle,
                    steerInput * adjustedSteer,
                    Time.deltaTime * 5f
                );
            }
        }
    }
    //Metodo para aceleracion y frenado del coche
    void Move()
    {
        if (enZonaFrenado)
        {
            foreach (var wheel in wheels)
            {
                wheel.wheelCollider.motorTorque = 0;
                wheel.wheelCollider.brakeTorque = brakeAcceleration;
            }
        }
        else if (Mathf.Abs(moveInput) > 0.05f)
        {
            float torqueFactor = Mathf.Clamp01(1f - (carRb.velocity.magnitude / 60f));
            foreach (var wheel in wheels)
            {
                wheel.wheelCollider.motorTorque = -moveInput * maxAcceleration * torqueFactor;
                wheel.wheelCollider.brakeTorque = 0;
            }
        }
        else
        {
            foreach (var wheel in wheels)
            {
                wheel.wheelCollider.motorTorque = 0;
                wheel.wheelCollider.brakeTorque = 0;
            }
        }
    }
    //Metodo de animacion de giro de las ruedas
    void AnimateWheels()
    {
        foreach (var wheel in wheels)
        {
            Quaternion rot;
            Vector3 pos;
            wheel.wheelCollider.GetWorldPose(out pos, out rot);
            wheel.wheelModel.transform.position = pos;
            wheel.wheelModel.transform.rotation = rot;
        }
    }
}
