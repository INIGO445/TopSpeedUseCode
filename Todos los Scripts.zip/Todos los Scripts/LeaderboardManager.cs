using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using SimpleJSON;

public class LeaderboardManager : MonoBehaviour
{
    private string nombreUsuario = GameManager.Instance.nombreJugador;
    [System.Serializable]
    public class DatosTiempo
    {
        public string Nombre;
        public float Tiempo;
    }
    public IEnumerator ObtenerLeaderboard()
    {
        string url = "https://topspeed-51f83-default-rtdb.europe-west1.firebasedatabase.app/prueba.json";

        UnityWebRequest request = UnityWebRequest.Get(url);
        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Error al obtener leaderboard: " + request.error);
            yield break;
        }

        string json = request.downloadHandler.text;

        if (string.IsNullOrEmpty(json) || json == "null")
        {
            Debug.Log("ℹNo hay datos aún en la base de datos.");
            yield break;
        }

        var datosLista = new List<DatosTiempo>();
        var jsonParsed = JSON.Parse(json);

        foreach (var item in jsonParsed)
        {
            string nombre = item.Value["Nombre"];
            float tiempo = item.Value["Tiempo"].AsFloat;

            datosLista.Add(new DatosTiempo { Nombre = nombre, Tiempo = tiempo });
        }

        datosLista.Sort((a, b) => a.Tiempo.CompareTo(b.Tiempo));

        Debug.Log("TOP 10 TIEMPOS:");
        bool estoyEnTop = false;
        int posicionReal = -1;

        for (int i = 0; i < datosLista.Count; i++)
        {
            var dato = datosLista[i];
            if (i < 10)
                Debug.Log($"{i + 1}. {dato.Nombre} - {dato.Tiempo:F2} segundos");

            if (dato.Nombre == nombreUsuario)
            {
                posicionReal = i + 1;
                if (i < 10)
                {
                    Debug.Log($"¡Enhorabuena {nombreUsuario}! Estás en el TOP 10 en la posición #{posicionReal}.");
                    estoyEnTop = true;
                }
            }
        }

        if (!estoyEnTop)
        {
            if (posicionReal > 0)
                Debug.Log($"ℹ{nombreUsuario} no está en el TOP 10, pero ocupa la posición #{posicionReal}.");
            else
                Debug.Log($"ℹ{nombreUsuario} no tiene registro en la tabla.");
        }
    }
}
