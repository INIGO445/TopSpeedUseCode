using UnityEngine;
using System;
using System.Collections.Generic;
using Unity.Netcode;
using Cinemachine;
using Unity.Netcode.Components;

public class F1Multijugador : NetworkBehaviour
{
    //Enum para el futura inclusion de mando de consola jugable
    public enum ControlMode
    {
        Keyboard,
        Buttons
    };
    //Enum para identificar si el eje es delantero o trasero
    public enum Axel
    {
        Front,
        Rear
    }
    //Struct para la Rueda
    [Serializable]
    public struct Wheel
    {
        public GameObject wheelModel;
        public WheelCollider wheelCollider;
        public Axel axel;
    }
    //Atributos para el que el coche pueda hacer movientos de izquierda a derecha acelerar y frenar
    public ControlMode control;
    public float maxAcceleration = 650.0f;
    public float turnSensitivity = 1.0f;
    public float maxSteerAngle = 30.0f;
    public Vector3 _centerOfMass;
    public List<Wheel> wheels;
    private float moveInput;
    private float steerInput;
    private Rigidbody carRb;
    public GameObject localCameraPrefab;
    private NetworkTransform networkTransform;
    //Inicializacion de los atributos y creacion de una instancia de una camara y asignacion a el jugador, if necesario para ver si la instacia es del jugador, para no alterar
    void Start()
    {
        if (!IsOwner)
        {
            enabled = false;
            return;
        }
        carRb = GetComponent<Rigidbody>();
        carRb.centerOfMass = _centerOfMass;
        foreach (var wheel in wheels)
        {
            WheelFrictionCurve forwardFriction = wheel.wheelCollider.forwardFriction;
            forwardFriction.stiffness = 1.5f;
            wheel.wheelCollider.forwardFriction = forwardFriction;

            WheelFrictionCurve sidewaysFriction = wheel.wheelCollider.sidewaysFriction;
            sidewaysFriction.stiffness = 2.5f;
            wheel.wheelCollider.sidewaysFriction = sidewaysFriction;
        }
        var cam = Instantiate(localCameraPrefab);
        var vcam = cam.GetComponentInChildren<Cinemachine.CinemachineVirtualCamera>();
        if (vcam != null)
        {
            vcam.Follow = transform;
            vcam.LookAt = transform;
        }
        networkTransform = GetComponent<NetworkTransform>();
    }
    //Metodos para recoger datos del teclado
    void Update()
    {
        if (!IsOwner) return;

        GetInputs();
        AnimateWheels();
    }
    void LateUpdate()
    {
        if (!IsOwner) return;

        Move();
        Steer();
    }
    public void MoveInput(float input)
    {
        moveInput = input;
    }
    public void SteerInput(float input)
    {
        steerInput = input;
    }
    void GetInputs()
    {
        if (control == ControlMode.Keyboard)
        {
            moveInput = Input.GetAxis("Vertical");
            steerInput = Input.GetAxis("Horizontal");
        }
    }
    //Calculo de los angulo de giro de las ruedas
    void Steer()
    {
        foreach (var wheel in wheels)
        {
            if (wheel.axel == Axel.Front)
            {
                var _steerAngle = steerInput * turnSensitivity * maxSteerAngle;
                wheel.wheelCollider.steerAngle = Mathf.Lerp(wheel.wheelCollider.steerAngle, _steerAngle, 0.6f);
            }
        }
    }
    //Calculo de los angulo de aceleracion de las ruedas
    void Move()
    {
        if (Mathf.Abs(moveInput) > 0.05f)
        {
            foreach (var wheel in wheels)
            {
                wheel.wheelCollider.motorTorque = -moveInput * maxAcceleration;
                wheel.wheelCollider.brakeTorque = 0;
            }
        }
        else
        {
            foreach (var wheel in wheels)
            {
                wheel.wheelCollider.motorTorque = 0;
                wheel.wheelCollider.brakeTorque = 0;
            }
        }
    }
    //Rotacion de las ruedas
    void AnimateWheels()
    {
        foreach (var wheel in wheels)
        {
            wheel.wheelCollider.GetWorldPose(out Vector3 pos, out Quaternion rot);
            wheel.wheelModel.transform.position = pos;
            wheel.wheelModel.transform.rotation = rot;
        }
    }
}
