using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using UnityEngine.SceneManagement;

public class MenuMultijugadorEleccion : MonoBehaviour
{
    private bool estaPausado = false;
    public GameObject menuPausa;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (estaPausado)
            {
                ContinuarJuego();
            }
            else
            {
                PausarJuego();
            }
        }
    }
    public void PausarJuego()
    {
        menuPausa.SetActive(true);
        estaPausado = true;
    }
    public void ContinuarJuego()
    {
        menuPausa.SetActive(false);
        estaPausado = false;
    }

    public void SalirDelJuego()
    {
        if (NetworkManager.Singleton != null && NetworkManager.Singleton.IsListening)
        {
            Debug.Log("Cerrando conexión de red...");
            NetworkManager.Singleton.Shutdown();
        }
        SceneManager.LoadScene("SampleScene");
    }
}
