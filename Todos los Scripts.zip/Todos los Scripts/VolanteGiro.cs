using UnityEngine;
using System;
using System.Collections.Generic;
using UnityEngine.InputSystem;

public class VolanteGiro : MonoBehaviour
{
    public Transform TransformMI;
    public float sensiGiro = 1f;
    public float giroI;
    public float giroMaximo = 30f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        giroI = Input.GetAxis("Horizontal");
        float anguloGiro = -giroI * sensiGiro * giroMaximo;
        Quaternion rotacionActual = transform.rotation;
        Quaternion rotacionObjetivo = Quaternion.Euler(rotacionActual.eulerAngles.x, rotacionActual.eulerAngles.y, anguloGiro);
        TransformMI.rotation = Quaternion.Lerp(rotacionActual, rotacionObjetivo, 0.6f);


    }
}
