using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;
using Unity.Netcode.Transports.UTP;
public class MenuSelectorMultiplayer : NetworkBehaviour
{
    public GameObject MenuMultijugador;
    // Start is called before the first frame update
    void Awake()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    public void Servidor()
    {
        MenuMultijugador.SetActive(false);
        NetworkManager.Singleton.StartHost();
    }
    public void Cliente()
    {
        MenuMultijugador.SetActive(false);
        NetworkManager.Singleton.StartClient();
    }
}
