using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
public enum GearState
{
    Neutral,
    Running,
    CheckingChange,
    Changing
};

public class CarController : MonoBehaviour
{
    private Rigidbody playerRB;
    public WheelColliders colliders;
    public WheelMeshes wheelMeshes;
    public float gasInput;
    private float brakeInput;
    private float steeringInput;
    public float motorPower;
    public float brakePower;
    public float slipAngle;
    public float speed;
    public float maxSteering=70f;
    public int isEngineRunning;
    private float clutch;
    public AnimationCurve steeringCurve;
    private GearState gearState;
    private bool handrbake = false;

    // Start is called before the first frame update
    void Start()
    {
        playerRB = gameObject.GetComponent<Rigidbody>();
    }
    void Update()
    {
        speed = playerRB.velocity.magnitude;
        CheckInput();
        ApplyMotor();
        //ApplyGiro();
        //ApplyBrake();
        ApplyWheelPositions();
    }
    void CheckInput()
    {
        gasInput = Input.GetAxis("Vertical");
        steeringInput = Input.GetAxis("Horizontal");
        //slipAngle = Vector3.Angle(transform.forward, playerRB.velocity - transform.forward);
        // if(slipAngle < 120f)
        // {
        //     if (gasInput < 0)
        //     {
        //         brakeInput = Mathf.Abs(gasInput);
        //         gasInput = 0;
        //     }
        //     else
        //     {
        //         brakeInput = 0;
        //     }
        // }
        // else
        // {
        //     brakeInput = 0;
        // }
    }


    public void SetInput(float throttleIn, float steeringIn, float clutchIn, float handbrakeIn)
    {
        gasInput = throttleIn;

        if (Mathf.Abs(gasInput) > 0 && isEngineRunning == 0)
        {
            //StartCoroutine(GetComponent<EngineAudio>().StartEngine());
            gearState = GearState.Running;
        }
        ApplySteering(steeringIn);

        slipAngle = Vector3.Angle(transform.forward, playerRB.velocity - transform.forward);

        //fixed code to brake even after going on reverse by Andrew Alex 
        float movingDirection = Vector3.Dot(transform.forward, playerRB.velocity);
        if (gearState != GearState.Changing)
        {
            if (gearState == GearState.Neutral)
            {
                clutch = 0;
                if (Mathf.Abs(gasInput) > 0) gearState = GearState.Running;
            }
            else
            {
                clutch = Mathf.Abs(1-clutchIn);
            }
        }
        else
        {
            clutch = 0;
        }
        if (movingDirection < -0.5f && gasInput > 0)
        {
            brakeInput = Mathf.Abs(gasInput);
        }
        else if (movingDirection > 0.5f && gasInput < 0)
        {
            brakeInput = Mathf.Abs(gasInput);
        }
        else
        {
            brakeInput = 0;
        }
        handrbake = (handbrakeIn>0.5);

    }

    void ApplyBrake()
    {
        colliders.FRWheel.brakeTorque = brakeInput * brakePower* 0.7f ;
        colliders.FLWheel.brakeTorque = brakeInput * brakePower * 0.7f;

        colliders.RRWheel.brakeTorque = brakeInput * brakePower * 0.3f;
        colliders.RLWheel.brakeTorque = brakeInput * brakePower *0.3f;


    }
    void ApplyMotor() {

        //currentTorque = CalculateTorque();
        colliders.RRWheel.motorTorque = motorPower * gasInput;
        colliders.RLWheel.motorTorque = motorPower * gasInput;
        // if (Input.GetKey(KeyCode.W))
        //   {
        //        rueda.RuedaColision.brakeTorque = 0f;
        //        rueda.RuedaColision.motorTorque = -150f * aceleracionMaxima * Time.deltaTime; //Aceleracion del coche
        //    }
        //    else if (Input.GetKey(KeyCode.S))
        //   {
        //        rueda.RuedaColision.motorTorque = +20f * aceleracionFreno * Time.deltaTime; //Freno del coche, si se frena, las ruedas hacer un efecto de bloqueo, y si se frena en la curva, este se ira recto, como en la f1
        //        rueda.RuedaColision.attachedRigidbody.angularDrag = 10f;
        //    }

    }

    public void ApplySteering(float steeringAngle)
    {

        //float steeringAngle = steeringInput*steeringCurve.Evaluate(speed);
        if (slipAngle < 120f)
        {
            steeringAngle += Vector3.SignedAngle(transform.forward, playerRB.velocity + transform.forward, Vector3.up);
        }
        steeringAngle = Mathf.Clamp(steeringAngle, -maxSteering, maxSteering);
        colliders.FRWheel.steerAngle = steeringAngle;
        colliders.FLWheel.steerAngle = steeringAngle;
    }
    public void ApplyGiro()
    {
        float steeringAngle = steeringInput*steeringCurve.Evaluate(speed);
        colliders.FRWheel.steerAngle = steeringAngle;
        colliders.FLWheel.steerAngle = steeringAngle;
    }

    void ApplyWheelPositions()
    {
        UpdateWheel(colliders.FRWheel, wheelMeshes.FRWheel);
        UpdateWheel(colliders.FLWheel, wheelMeshes.FLWheel);
        UpdateWheel(colliders.RRWheel, wheelMeshes.RRWheel);
        UpdateWheel(colliders.RLWheel, wheelMeshes.RLWheel);
        // Listo
    }
    void UpdateWheel(WheelCollider coll, GameObject wheelMesh)
    {
        Quaternion quat;
        Vector3 position;
        coll.GetWorldPose(out position, out quat);
        wheelMesh.transform.position = position;
        wheelMesh.transform.rotation = quat;
    } //Listo
[System.Serializable]
public class WheelColliders
{
    public WheelCollider FRWheel;
    public WheelCollider FLWheel;
    public WheelCollider RRWheel;
    public WheelCollider RLWheel;
}
[System.Serializable]
public class WheelMeshes
{
    public GameObject FRWheel;
    public GameObject FLWheel;
    public GameObject RRWheel;
    public GameObject RLWheel;
}
}


// public class CarController : MonoBehaviour
// {
//     public enum AlanteOAtras
//     {
//         Alante,
//         Atras
//     }
//     [Serializable]
//     public struct Rueda
//     {
//         public GameObject RuedaModelo;
//         public WheelCollider RuedaColision;
//         public AlanteOAtras alanteOAtras;
//     }
//     public float aceleracionMaxima;
//     public float aceleracionFreno;
//     public float sensiGiro = 1f;
//     public float giroMaximo = 30f;
//     public List<Rueda> ruedas;
//     public Vector3 centro;
//     float giroI;
//     float velocidad;
//     private Rigidbody carRb;
//     void Start()
//     {
//         aceleracionFreno = 100f;
//         carRb = GetComponent<Rigidbody>();
//         carRb.centerOfMass = centro;
//     }
//     void Update()
//     {
//         GetInputs();
//         AnimacionesRuedas();
//         Move();
        
//     }
//     void LateUpdate()
//     {
//         Giro();
//     }
//     void GetInputs()
//     {
//         giroI = Input.GetAxis("Horizontal");
//         velocidad = Input.GetAxis("Vertical");
//     }
//     void Move()
//     {
//         foreach (var rueda in ruedas)
//         {
//            if (Input.GetKey(KeyCode.W))
//           {
//                rueda.RuedaColision.brakeTorque = 0f;
//                rueda.RuedaColision.motorTorque = -150f * aceleracionMaxima * Time.deltaTime; //Aceleracion del coche
//            }
//            else if (Input.GetKey(KeyCode.S))
//           {
//                rueda.RuedaColision.motorTorque = +20f * aceleracionFreno * Time.deltaTime; //Freno del coche, si se frena, las ruedas hacer un efecto de bloqueo, y si se frena en la curva, este se ira recto, como en la f1
//                rueda.RuedaColision.attachedRigidbody.angularDrag = 10f;
//            }
//            else
//            {
//                rueda.RuedaColision.brakeTorque = 0f;
//                rueda.RuedaColision.motorTorque = 0f;
//                rueda.RuedaColision.attachedRigidbody.angularDrag = 0f; //El coche ira perdiendo velocidad, por su propia cuenta, no bloquea las ruedas, pierde la velocidad, por su aerodinamica
//            }
//         }
//     }
//     void Giro()
//     {
//         foreach(var rueda in ruedas)
//         {
//             if(rueda.alanteOAtras == AlanteOAtras.Alante)
//             {
//                 var anguloGiro = giroI * sensiGiro * giroMaximo;
//                 rueda.RuedaColision.steerAngle = Mathf.Lerp(rueda.RuedaColision.steerAngle, anguloGiro, 0.6f); // HAcemos que la colisiond e la rueda roto para poder mover el vehiculo
//             }
//         }
//     }
//     void AnimacionesRuedas()
//     {
//         foreach (var rueda in ruedas)
//         {
//             Quaternion rotacion;
//             Vector3 posicion;
//             rueda.RuedaColision.GetWorldPose(out posicion, out rotacion);
//             rueda.RuedaModelo.transform.position = posicion;
//             rueda.RuedaModelo.transform.rotation = rotacion; // Hacemos una animacion a la rueda, para que de la sensacion de giro
//         }
//     }
// }
// }

