using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(CarController))]
public class AICarControllert : MonoBehaviour
{
    public WaypointContainer waypointContainer;
    public List<Transform> waypoints;
    public int currentWaypoint;
    private CarController carController;
    public float waypointrange;
    private float currentAngle;
    // Start is called before the first frame update
    void Start()
    {
        carController = GetComponent<CarController>();
        waypoints = waypointContainer.waypoints;
        currentWaypoint = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if(Vector3.Distance(waypoints[currentWaypoint].position,transform.position)<waypointrange)
        {
            Debug.Log("Cambio");
            currentWaypoint++;
            if(currentWaypoint == waypoints.Count) currentWaypoint = 0;
        }
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        //currentAngle = Vector3.SignedAngle(fwd,waypoints[currentWaypoint].position-transform.position,Vector3.up);
        //carController.SetInput(1, currentAngle, 0, 0);

        Debug.DrawRay(transform.position,waypoints[currentWaypoint].position-transform.position, Color.blue);
    }
}
