using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class MenuPrincipal : MonoBehaviour
{
    public TMP_InputField nombreInput;
    public void SinglePlayer()
    {
        if (!string.IsNullOrEmpty(nombreInput.text))
        {
            GameManager.Instance.nombreJugador = nombreInput.text;
            SceneManager.LoadScene("Singleplayer");
        }
        else
        {
            Debug.LogWarning("Introduce un nombre antes de continuar.");
        }
    }
    public void MultiPlayer()
    {
        if (!string.IsNullOrEmpty(nombreInput.text))
        {
            GameManager.Instance.nombreJugador = nombreInput.text;
            SceneManager.LoadScene("Multiplayer");
        }
    }
}
