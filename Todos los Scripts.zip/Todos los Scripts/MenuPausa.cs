using UnityEngine;

public class MenuPausa : MonoBehaviour
{
    public GameObject menuPausa;
    public GameObject leaderboardCanvas;
    private bool estaPausado = false;
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (leaderboardCanvas.activeSelf && leaderboardCanvas != null)
            {
                leaderboardCanvas.SetActive(false);
                menuPausa.SetActive(true);
                return;
            }

            if (estaPausado)
            {
                ContinuarJuego();
            }
            else
            {
                PausarJuego();
            }
        }
    }
    public void PausarJuego()
    {
        menuPausa.SetActive(true);
        Time.timeScale = 0f;
        estaPausado = true;
    }
    public void ContinuarJuego()
    {
        menuPausa.SetActive(false);
        Time.timeScale = 1f;
        estaPausado = false;
    }
    public void SalirDelJuego()
    {
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene("SampleScene");
    }
    public void VerLeaderboard()
    {
        leaderboardCanvas.SetActive(true);
        menuPausa.SetActive(false);
    }
}
