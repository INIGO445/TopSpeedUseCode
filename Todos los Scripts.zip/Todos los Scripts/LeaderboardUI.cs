using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using System.Collections;
using System.Collections.Generic;
using SimpleJSON;

public class LeaderboardUI : MonoBehaviour
{
    public Transform content;
    public GameObject entradaPrefab;
    private string nombreJugador = GameManager.Instance.nombreJugador;
    private string url = "https://topspeed-51f83-default-rtdb.europe-west1.firebasedatabase.app/prueba.json";
    [System.Serializable]
    public class DatosTiempo
    {
        public string Nombre;
        public float Tiempo;
    }
    void Awake()
    {
        StartCoroutine(ObtenerLeaderboard());
    }

    public void Update()
    {
        StartCoroutine(ObtenerLeaderboard());
    }
    //Metodo para recupera y asignar los datros de los jugadores
    IEnumerator ObtenerLeaderboard()
    {
        UnityWebRequest request = UnityWebRequest.Get(url);
        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Error al obtener leaderboard: " + request.error);
            yield break;
        }

        string json = request.downloadHandler.text;

        if (string.IsNullOrEmpty(json) || json == "null")
        {
            Debug.Log("ℹNo hay datos aún en la base de datos.");
            yield break;
        }

        var datosLista = new List<DatosTiempo>();
        var jsonParsed = JSON.Parse(json);

        foreach (var item in jsonParsed)
        {
            string nombre = item.Value["Nombre"];
            float tiempo = item.Value["Tiempo"].AsFloat;

            datosLista.Add(new DatosTiempo { Nombre = nombre, Tiempo = tiempo });
        }

        datosLista.Sort((a, b) => a.Tiempo.CompareTo(b.Tiempo));

        foreach (Transform hijo in content)
        {
            Destroy(hijo.gameObject);
        }

        bool jugadorEnTop = false;
        int posicionJugador = -1;

        for (int i = 0; i < datosLista.Count; i++)
        {
            DatosTiempo dato = datosLista[i];

            if (i < 10)
            {
                GameObject entrada = Instantiate(entradaPrefab, content);
                TextMeshProUGUI[] textos = entrada.GetComponentsInChildren<TextMeshProUGUI>();

                textos[0].text = $"{i + 1}.";               
                textos[1].text = dato.Nombre;               
                textos[2].text = $"{dato.Tiempo:F2}s";      

                if (dato.Nombre == nombreJugador)
                {
                    jugadorEnTop = true;
                    foreach (var t in textos)
                        t.color = Color.green;
                }
            }

            if (dato.Nombre == nombreJugador)
            {
                posicionJugador = i + 1;
            }
        }

        if (!jugadorEnTop && posicionJugador > 10)
        {
            GameObject entradaExtra = Instantiate(entradaPrefab, content);
            TextMeshProUGUI[] textos = entradaExtra.GetComponentsInChildren<TextMeshProUGUI>();

            textos[0].text = $"{posicionJugador}.";     
            textos[0].color = Color.green;
            textos[1].text = nombreJugador;             
            textos[1].color = Color.green;
            textos[2].text = $"{datosLista[posicionJugador - 1].Tiempo:F2}s"; 
            textos[2].color = Color.green;
        }
    }
}
