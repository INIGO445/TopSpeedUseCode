using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultiplayerCamera : MonoBehaviour
{
    public Transform player;
    public Vector3 Offset;
    public Vector3 Offset2;
    public float smoothTime = 0.3f;
    private Vector3 velocity;

    void FixedUpdate()
    {
        if (player == null) return;

        Camera.main.transform.LookAt(player.position + Offset2);
        Vector3 targetPosition = player.position + player.TransformVector(Offset) + player.forward * -5f;
        Camera.main.transform.position = Vector3.SmoothDamp(Camera.main.transform.position, targetPosition, ref velocity, smoothTime);
    }
}
