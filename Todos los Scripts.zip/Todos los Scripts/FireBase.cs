using UnityEngine;
using UnityEngine.Networking;
using System.Collections;

public class TestFirebase : MonoBehaviour
{
    void Start()
    {
        StartCoroutine(EnviarTest());
    }

    IEnumerator EnviarTest()
    {
        string url = "https://topspeed-51f83-default-rtdb.europe-west1.firebasedatabase.app/prueba.json";
        string json = "{\"mensaje\": \"Hola desde Unity\"}";

        UnityWebRequest request = UnityWebRequest.Put(url, json);
        request.method = UnityWebRequest.kHttpVerbPUT;
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("¡Datos enviados!");
        }
        else
        {
            Debug.LogError("Error al enviar: " + request.error);
        }
    }
}
